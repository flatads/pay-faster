package com.example.payfasterdemo;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

import com.paymentgateway.paysdk.PayServiceListener;
import com.paymentgateway.paysdk.PayServiceNative;
import com.paymentgateway.paysdk.pay.model.PayError;
import com.paymentgateway.paysdk.pay.model.PayOrder;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class MainActivity extends AppCompatActivity {

    private final static int REQ_CODE = 998;
    private final static String TAG = "MainActivity";
    private String mOrderId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        findViewById(R.id.btn_india).setOnClickListener(v -> startPay(PayOrder.PAY_COUNTRY.IN));

        findViewById(R.id.btn_other).setOnClickListener(v -> startPay(PayOrder.PAY_COUNTRY.ALL));
    }

    //拉起支付的activity的onActivityResult方法中获取支付结果
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        PayServiceNative.onActivityResult(mOrderId, requestCode, resultCode, data, mPayServiceListener);
    }

    private final PayServiceListener mPayServiceListener = new PayServiceListener() {

        @Override
        public void onPayError(String orderId, PayError payError) {
            //支付失败
            Log.e(TAG, "onPayError: " + orderId + ", " + payError.getMsg());
        }

        @Override
        public void onBackPressedCancel(String orderId) {
            //支付取消
            Log.i(TAG, "onBackPressedCancel: " + orderId);
        }

        @Override
        public void onTranPending(String orderId, String errMsg) {
            //支付中
            Log.i(TAG, "onTranPending: " + orderId + ", " + errMsg);
        }

        @Override
        public void onPaySuccess(String orderId) {
            //支付成功
            Log.i(TAG, "onPaySuccess: " + orderId);
        }
    };


    //拉起支付，请在UI线程中调用
    private void startPay(String country) {

        //【1】设置环境,在开发的过程中请使用测试环境： true - 测试环境， false - 正式环境
        PayServiceNative.getInstance().setDebugMode(false);

        //【2】创建订单，每次点击PayBtn时，都需要创建新的订单Id(m_order_id)，否则不能支付成功
        PayOrder payOrder = buildPayOrder(country);

        mOrderId = payOrder.getmOrderId();

        //【3】记录数据，用户在接入方开始请求支付的事件
        PayServiceNative.getInstance().payBtnClickReport(this, payOrder.mid, payOrder.uid);

        // 【4】启动支付,UI线程调用 REQ_CODE大于0即可，可以自己设置一个不冲突的REQ_CODE
        PayServiceNative.getInstance().startPayTransaction(this, payOrder, REQ_CODE);
    }


    public static PayOrder buildPayOrder(String country) {
        //mid和secret，我方提供
        // TODO: 运行demo，需要补充这两个参数
        String mid = "";
        String secret = "";

        //以下参数都为必填

        //订单号
        String order_id = String.valueOf((int) ((Math.random() * 9 + 1) * 100000000));
        //用户id
        String uid = "12345543";
        //支付结果回调url
        String callback_url = "";
        //用户实际支付金额，最多精确到小数点后两位（必填）
        String pay_amount = "1.00";
        //用户手机号（必填，获取不到，填入一个默认的7777777777）
        String phone_number = "7777777777";
        //是否为真实手机号，可不设置
        boolean isRealPhone = true;
        //支付货币单位，印度传入"INR"，其他国家地区要求传入对应国家的货币单位
        String unit = "INR";
        //商品名称或订单名称
        String order_name = "Title";
        //渠道
        String channel_id = "";
        //已弃用 客户端类型，不可为null，空字符串即可
        String client_type = "";
        //服务器生成的checksum
        String checksum;

        //userName和email不参与checksum的生成，由于部分支付方式要求，请尽可能提供这两项信息。
        //用户名，昵称
        String userName = "";
        //邮箱
        String email = "";

        //生成checksum，请在服务器生成该值
        String param = callback_url + channel_id + client_type + order_id
                + mid + order_name + pay_amount + phone_number
                + uid + unit + secret;
        checksum = getSHA256(param);

        PayOrder payOrder = new PayOrder();
        payOrder.setMid(mid);
        payOrder.setmOrderId(order_id);
        payOrder.setUid(uid);
        payOrder.setCallbackUrl(callback_url);
        payOrder.setPayAmount(pay_amount);
        payOrder.setPhoneNumber(phone_number);
        payOrder.setRealPhone(isRealPhone);
        payOrder.setUnit(unit);
        payOrder.setOrderName(order_name);
        payOrder.setChannelId(channel_id);
        //已弃用
        payOrder.setClientType(client_type);
        payOrder.setChecksum(checksum);
        payOrder.setUserName(userName);
        payOrder.setEmail(email);
        payOrder.setCountry(country);
        return payOrder;
    }

    public static String getSHA256(String str) {
        MessageDigest messageDigest;
        String encodestr = "";
        try {
            messageDigest = MessageDigest.getInstance("SHA-256");
            messageDigest.update(str.getBytes(StandardCharsets.UTF_8));
            byte[] digest = messageDigest.digest();
            encodestr = byte2Hex(digest);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return encodestr;
    }

    private static String byte2Hex(byte[] bytes) {
        StringBuilder stringBuffer = new StringBuilder();
        String temp;
        for (byte aByte : bytes) {
            temp = Integer.toHexString(aByte & 0xFF);
            if (temp.length() == 1) {
                stringBuffer.append("0");
            }
            stringBuffer.append(temp);
        }
        return stringBuffer.toString();
    }

}